# RoboLearn Complete

## Windows setup

1. Install Node.js 22.13 or newer from https://nodejs.org/.
2. Open PowerShell in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open http://localhost:3000 in a browser.

The SQLite database is created at `robolearn.db` using Node's built-in SQLite module, so no platform-specific SQLite binary is required. User passwords are hashed with bcrypt. The app includes responsive pages for Home, Robotics, Projects, Products, Cart, Checkout, About, Blog, Tutorials and Contact, plus login and registration.

## Useful commands

- `npm start` starts the local server.
- `npm test` checks the API status, product search, signup/login flow and contact endpoint.

For production, set a strong `SESSION_SECRET` environment variable and use HTTPS.

## Free public hosting with Render

The included `render.yaml` is ready for Render's free web service:

1. Create a free account at https://render.com/.
2. Create a GitHub repository and upload this project (do not upload `node_modules`).
3. In Render, choose **New +** → **Blueprint**.
4. Select the GitHub repository and deploy.
5. Wait for the build to finish, then open the HTTPS URL Render provides.

Use that HTTPS URL on school computers and phones. Do not use `localhost`.

If you already created the Render service, push the latest project files to the connected GitHub branch and choose **Manual Deploy** → **Deploy latest commit**. The server requires Node.js 22.13 or newer and must be deployed as a **Web Service**, not a Static Site.

Important: Render's free service can sleep and its local filesystem is temporary. The app will run publicly, but SQLite users and orders can be reset after a service restart. For permanent production data, connect the app to a hosted PostgreSQL database before launch.
