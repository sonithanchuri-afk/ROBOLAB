// ========================================
// ROBOLEARN CART
// ========================================

function getCart() {
    try {
        const savedCart = localStorage.getItem("robolearnCart");

        if (!savedCart) {
            return [];
        }

        const cart = JSON.parse(savedCart);

        return Array.isArray(cart) ? cart : [];

    } catch (error) {

        console.error("Could not load cart:", error);

        return [];
    }
}


function saveCart(cart) {
    try {

        localStorage.setItem(
            "robolearnCart",
            JSON.stringify(cart)
        );

    } catch (error) {

        console.error("Could not save cart:", error);

    }
}


function addProductToCart(product) {

    if (!product || !product.id) {
        console.error("Invalid product.");
        return;
    }

    const cart = getCart();

    const existingProduct =
        cart.find(item => item.id === product.id);

    if (existingProduct) {

        existingProduct.quantity += 1;

    } else {

        cart.push({
            id: product.id,
            name: product.name,
            price: Number(product.price),
            quantity: 1
        });

    }

    saveCart(cart);

    updateCartCount();

    alert(`${product.name} added to your cart!`);
}


function updateCartCount() {

    const cartCount =
        document.getElementById("cart-count");

    if (!cartCount) {
        return;
    }

    const cart = getCart();

    const totalItems = cart.reduce(
        (total, item) => total + item.quantity,
        0
    );

    cartCount.textContent = totalItems;
}


document.addEventListener(
    "DOMContentLoaded",
    updateCartCount
);