const assert = require("assert");
const { spawn } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");

const databasePath = path.join(os.tmpdir(), `robolearn-test-${process.pid}.db`);
const child = spawn(process.execPath, ["server.js"], {
  stdio: "ignore",
  env: { ...process.env, DATABASE_PATH: databasePath }
});
const request = async (route, method = "GET", data) => {
  const response = await fetch(`http://127.0.0.1:3000${route}`, {
    method,
    headers: data ? { "Content-Type": "application/json" } : {},
    body: data ? JSON.stringify(data) : undefined
  });
  return { status: response.status, body: await response.json().catch(() => null) };
};

(async () => {
  try {
    await new Promise(resolve => setTimeout(resolve, 1200));
    assert.equal((await request("/api/status")).status, 200);
    assert.equal((await request("/api/products?search=arduino")).body.length, 1);
    assert.equal((await request("/api/products?category=Electronics")).body.length, 2);

    const email = `test-${Date.now()}@example.com`;
    const credentials = { name: "Test User", email, password: "test-password-123" };
    assert.equal((await request("/api/signup", "POST", credentials)).status, 201);
    assert.equal((await request("/api/signup", "POST", credentials)).status, 409);
    assert.equal((await request("/api/login", "POST", { email, password: "wrong-password" })).status, 401);
    assert.equal((await request("/api/login", "POST", credentials)).status, 200);

    const contact = await request("/api/messages", "POST", { name: "Test User", email, message: "Testing contact form." });
    assert.equal(contact.status, 200);
    const order = await request("/api/orders", "POST", {
      name: "Test User", phone: "1234567890", email, address: "1 Test Street",
      city: "Test City", state: "Test State", pincode: "123456",
      items: [{ id: "starter-kit", quantity: 2 }]
    });
    assert.equal(order.status, 201);
    assert.equal(order.body.total, 4998);
    assert.equal((await request("/")).status, 200);
    console.log("RoboLearn API, SQLite, authentication, contact, and order tests passed.");
  } finally {
    child.kill();
    if (child.exitCode === null) await new Promise(resolve => child.once("exit", resolve));
    for (const suffix of ["", "-journal", "-wal", "-shm"]) {
      const file = databasePath + suffix;
      if (fs.existsSync(file)) fs.rmSync(file);
    }
  }
})().catch(error => {
  console.error(error);
  process.exitCode = 1;
});
