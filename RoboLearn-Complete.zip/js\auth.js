
function updateAuthUI() {
    const authArea = document.getElementById("auth-area");

    if (authArea) {
        authArea.innerHTML = "";
    }
}

document.addEventListener("DOMContentLoaded", updateAuthUI);
