const { DatabaseSync } = require("node:sqlite");
const path = require("path");

const db = new DatabaseSync(process.env.DATABASE_PATH || path.join(__dirname, "robolearn.db"));
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL,
    email TEXT NOT NULL, address TEXT NOT NULL, city TEXT NOT NULL, state TEXT NOT NULL,
    pincode TEXT NOT NULL, items TEXT NOT NULL, total REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending', created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL,
    message TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

module.exports = db;
