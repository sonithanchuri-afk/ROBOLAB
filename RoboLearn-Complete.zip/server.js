const express = require("express");
const session = require("express-session");
const bcrypt = require("bcrypt");
const path = require("path");
const db = require("./database");

const app = express();
const PORT = process.env.PORT || 3000;
const products = [
  { id: "starter-kit", name: "RoboLearn Starter Kit", category: "Kits", price: 2499, icon: "🔧", description: "Everything you need to build your first sensor-powered robot." },
  { id: "line-follower", name: "Line Follower Kit", category: "Kits", price: 1899, icon: "🚗", description: "Build and program an autonomous line-following rover." },
  { id: "arduino-pack", name: "Arduino Sensor Pack", category: "Electronics", price: 999, icon: "⚡", description: "A practical collection of sensors, wires and components." },
  { id: "servo-bundle", name: "Servo Motor Bundle", category: "Electronics", price: 749, icon: "⚙️", description: "Four reliable micro servos for mechanisms and prototypes." },
  { id: "robotics-course", name: "Robotics Foundations Course", category: "Learning", price: 1499, icon: "🎓", description: "A guided beginner course from circuits to autonomous robots." },
  { id: "safety-goggles", name: "Lab Safety Goggles", category: "Lab Gear", price: 299, icon: "🥽", description: "Comfortable eye protection for every electronics lab." }
];

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret: process.env.SESSION_SECRET || "robolearn-local-secret-change-me",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", maxAge: 86400000 }
}));
app.use(express.static(__dirname, { extensions: ["html"] }));

app.get("/api/status", (req, res) => res.json({ success: true, message: "RoboLearn API is running" }));
app.get("/api/products", (req, res) => {
  const search = String(req.query.search || "").toLowerCase();
  const category = String(req.query.category || "All");
  res.json(products.filter(p => (category === "All" || p.category === category) &&
    (!search || `${p.name} ${p.description} ${p.category}`.toLowerCase().includes(search))));
});
app.get("/api/me", (req, res) => res.json(req.session.user ? { loggedIn: true, user: req.session.user } : { loggedIn: false }));

app.post("/api/signup", async (req, res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  if (name.length < 2 || !/^\S+@\S+\.\S+$/.test(email) || password.length < 8)
    return res.status(400).json({ message: "Use a name, valid email, and password of at least 8 characters." });
  try {
    const hash = await bcrypt.hash(password, 12);
    const result = db.prepare("INSERT INTO users (name,email,password) VALUES (?,?,?)").run(name, email, hash);
    req.session.user = { id: Number(result.lastInsertRowid), name, email };
    res.status(201).json({ success: true, user: req.session.user });
  } catch (error) {
    if (error.message.includes("UNIQUE constraint failed")) return res.status(409).json({ message: "An account with that email already exists." });
    console.error(error);
    res.status(500).json({ message: "Could not create account." });
  }
});
app.post("/api/login", async (req, res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  try {
    const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email);
    if (!user || !(await bcrypt.compare(password, user.password))) return res.status(401).json({ message: "Email or password is incorrect." });
    req.session.user = { id: user.id, name: user.name, email: user.email };
    res.json({ success: true, user: req.session.user });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Database error." });
  }
});
app.post("/api/logout", (req, res) => req.session.destroy(() => res.json({ success: true })));
app.post("/api/messages", (req, res) => {
  const name = String(req.body.name || "").trim(), email = String(req.body.email || "").trim(), message = String(req.body.message || "").trim();
  if (!name || !/^\S+@\S+\.\S+$/.test(email) || message.length < 10) return res.status(400).json({ message: "Please provide a valid email and a message of at least 10 characters." });
  try {
    db.prepare("INSERT INTO messages (name,email,message) VALUES (?,?,?)").run(name, email, message);
    res.json({ success: true, message: "Thanks! We will reply soon." });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not send message." });
  }
});
app.post("/api/orders", (req, res) => {
  const { name, phone, email, address, city, state, pincode, items } = req.body;
  if (!name || !/^\d{10}$/.test(String(phone || "")) || !/^\S+@\S+\.\S+$/.test(String(email || "")) || !address || !city || !state || !/^\d{6}$/.test(String(pincode || "")) || !Array.isArray(items) || !items.length)
    return res.status(400).json({ message: "Please complete all checkout fields." });
  const safeItems = items.map(i => ({ id: i.id, quantity: Math.max(1, Math.min(20, Number(i.quantity) || 1)) }));
  const total = safeItems.reduce((sum, item) => { const p = products.find(x => x.id === item.id); return sum + (p ? p.price * item.quantity : 0); }, 0);
  try {
    const result = db.prepare("INSERT INTO orders (name,phone,email,address,city,state,pincode,items,total) VALUES (?,?,?,?,?,?,?,?,?)")
      .run(String(name).trim(), phone, String(email).trim(), String(address).trim(), String(city).trim(), String(state).trim(), pincode, JSON.stringify(safeItems), total);
    res.status(201).json({ success: true, orderId: Number(result.lastInsertRowid), total });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Could not save order." });
  }
});
app.get("/", (req, res) => res.sendFile(path.join(__dirname, "index.html")));
app.listen(PORT, () => console.log(`RoboLearn running at http://localhost:${PORT}`));
